<?php


namespace App\Interfaces;


interface FhirEntityInterface
{
    public function getCreateDateFromEntry($entry);
}
